public class Ex8 {
    public static void main(String[] args) {
        MyMath.newtonRaphson();
    }
}
