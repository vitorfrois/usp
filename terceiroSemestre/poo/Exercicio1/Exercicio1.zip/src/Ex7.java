public class Ex7 {
    public static void main(String[] args){
        MyMath.bissecao();
    }



}
