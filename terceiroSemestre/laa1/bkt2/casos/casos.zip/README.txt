Arquivo zip gerado em: 04/05/2022 10:53:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: BKT 2