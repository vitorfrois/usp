#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "../includes/myString.h"
#include "../includes/person.h"

#define WRITE 1
#define READ 2
#define PRINT 3
#define SKIPSIZE 238
typedef struct PERSON Person;


int main(){
    char *filename = readString();
    int command;
    scanf("%d", &command);
    FILE *fp;
    if(command == WRITE){
        fp = fopen(filename, "a+");
        inputPerson(fp);
    }else if(command == PRINT){
        fp = fopen(filename, "r+");
        int numRecords = numRecordsCalculator(fp);
        for(int i = 0; i < numRecords; i++)
            printPerson(fp);
        
    }else if(command == READ){
        fp = fopen(filename, "r+");
        int rrn;
        scanf("%d", &rrn);
        fseek(fp, rrn * SKIPSIZE, SEEK_SET); 
        printPerson(fp);
    }
    fclose(fp);
}