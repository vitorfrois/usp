Arquivo zip gerado em: 18/09/2024 08:31:10 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Hello World