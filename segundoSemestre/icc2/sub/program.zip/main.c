#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include "myString.h"

typedef long long int llint;

//Funções usadas na main
int hashing(char*, int, int);

typedef struct elem{
    char *word;
    int number, hashCode;
}Elem;
typedef Elem* Table;

int main(){
    //Inserção
    int n;
    scanf("%d\n", &n);
    int m = (n*13)/10;
    Table hashTable = malloc(sizeof(Elem) * m);

    for(int i = 0; i < m; i++){
        hashTable[i].word = "\0";
        hashTable[i].number = -1;
    }
    
    for(int i = 0; i < n; i++){
        Elem new;
        new.word = readString();
        scanf("%d\n", &new.number);
        int hashCode, colisions = 0;
        do{
            hashCode = hashing(new.word, m, colisions);
            colisions++;
        }while(hashTable[hashCode].number != -1);
        hashTable[hashCode] = new;
    }

    for(int i = 0; i < m; i++){
        if(hashTable[i].number != -1)
            printf("%d %s-%d\n", i, hashTable[i].word, hashTable[i].number);
    }

    //Busca
    printf("\n");
    int b;
    scanf("%d\n", &b);
    for(int i = 0; i < b; i++){
        char *searchedWord = readString();
        printf("%s-", searchedWord);
        int hashCode, colisions = 0;
        do{
            hashCode = hashing(searchedWord, m, colisions);
            colisions++;
        }while(strcmp(hashTable[hashCode].word, searchedWord) != 0 && colisions < m);
        if(colisions != m)
            printf("%d\n", hashTable[hashCode].number);
        else
            printf("NE\n");
    }
    free(hashTable);

    return 0;
}

int hashing(char *word, int m, int colisions){
    int size = (int) strlen(word);
    llint hashCode = 0; 
    for(int i = 0; i < size; i+=4)
        hashCode += (word[i] * (llint) pow(13.0, (double) (i/4)));

    hashCode = (hashCode + colisions) % m;
    return (int) hashCode;
}

