// Function to read and return the value of a string
char* readString(char *controler);
