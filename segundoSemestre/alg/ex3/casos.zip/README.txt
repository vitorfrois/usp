Arquivo zip gerado em: 28/09/2021 15:21:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 3