#ifndef DATA_H
#define DATA_h

#include "queue.h"

//Function to copy data from b to a
void dataCpy(Shell* a, Shell* b);

#endif
