#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
// #include "abb.h"
#include "sorts.h"


/**
 * @brief Create a new Binary Search Tree (BTS)
 * 
 * @return BST* 
 */
BST *create() {
	BST *a = (BST *)malloc(sizeof(BST));
	a->root = NULL;
	return a;
}

/**
 * @brief Check if the tree is empty
 * 
 * @param a tree
 * @return int 1 for empty, else, 0
 */
int isEmpty(BST *a) {
	assert(a != NULL);
	if(a->root == NULL)
		return 1;
	return 0;
}

/**
 * @brief Frees the BST recursively
 * 
 * @param root the root node of the tree
 */
void freeTree(t_node *root) {
	if(root != NULL) {
		freeTree(root->left);
		freeTree(root->right);
		free(root);
	}
}

/**
 * @brief Computes the heigth of the bst
 * 
 * @param root the primary root
 * @return the height (int)
 */
int height(t_node *root) {
	if(root == NULL) 
		return 0;
	
	int alt_left = 1 + height(root->left);
	int alt_right = 1 + height(root->right);
	
	if(alt_left > alt_right)
		return alt_left;
	else
		return alt_right;
}

/**
 * @brief Prints the tree recursively
 * 
 * @param root the primary root
 */
void printTree(t_node *root, char *option) {
	if(strcmp(option, "preordem") == 0) preOrder(root);
	else if(strcmp(option, "colored") == 0) preOrder2(root); 
	printf("\n");
}

void preOrder2(t_node *root) {
	if(root != NULL) {
		printf("\033[0;%dm", 31 + (root->s.frequency%8));
		printf("%c;%d(", root->s.representation, root->s.frequency);
		preOrder2(root->left);
		printf(",");
		preOrder2(root->right);
		printf("\033[0;%dm", 31 + (root->s.frequency%8));
		printf(")");
		printf("\033[0;39m");
	} else {
		printf("null");
	}
}

/**
 * @brief The root node gets visited first, followed by left and right subtrees. 
 * 
 * @param root the primary root
 */
void preOrder(t_node *root) {
	if(root != NULL) {
		printf("%d ", root->s.frequency);
		preOrder(root->left);
		preOrder(root->right);
	}
}

/**
 * @brief Search the root with info x
 * 
 * @param root the primary root
 * @param x the key
 * @return t_node* 
 */
char *searchTree(t_node *root, int freq, char *codified, int *x) {
	if(root) printf("nó atual = %d; procurando por %d\n", root->s.frequency, freq);
	if(freq > root->s.frequency) {
		codified[*x] = '1';
		*x += 1;
		searchTree(root->right, freq, codified, x);
	}else if(freq < root->s.frequency) {
		codified[*x] = '0';
		*x += 1;
		searchTree(root->left, freq, codified, x);
	}else if(freq == root->s.frequency){
		return codified;
	}
	return "uai";
}

void huffmanCompression(t_node** root, char arr[], int top){
	// if(*root) printf("nó atual = %c; top = %d\n", (*root)->s.representation, top);
    // Assign 0 to left edge and recur
    if ((*root)->left) {
        arr[top] = '0';
        huffmanCompression(&(*root)->left, arr, top + 1);
    }
    // Assign 1 to right edge and recur
    if ((*root)->right) {
        arr[top] = '1';
        huffmanCompression(&(*root)->right, arr, top + 1);
    }
    if (isLeaf((*root))) {
		(*root)->s.codified = malloc(sizeof(char) * (top + 1));
		for(int i = 0; i < top; i++)
			(*root)->s.codified[i] = arr[i];
		(*root)->s.codified[top] = '\0';
        // printf("%c: ", (*root)->s.representation);
		// for(int i = 0; i < top; i++)
		// 	printf("%c", arr[i]);
		// printf("\n");
    }
}

int isLeaf(t_node* root){
    return !(root->left) && !(root->right);
}

t_node **createNodeArray(int *charFrequency, int *nNodes){
	t_node **nodeArray = malloc(sizeof(t_node*) * ALPHABET_SIZE);
	for (int i = 0; i < ALPHABET_SIZE; i++){
        if(charFrequency[i] != 0){
            nodeArray[*nNodes] = malloc(sizeof(t_node));
            nodeArray[*nNodes]->left = NULL;
            nodeArray[*nNodes]->right = NULL;
            nodeArray[*nNodes]->s.representation = (char) i;
            nodeArray[*nNodes]->s.frequency = charFrequency[i];
            (*nNodes) += 1;
        }
    }
    quicksort(nodeArray, 0, *nNodes);
	return nodeArray;
}

t_node **createHuffmanTable(t_node** nodeArray, int nodeArraySize){
	int huffmanTableSize = nodeArraySize;
	t_node **huffmanTable = malloc(sizeof(t_node*) * ALPHABET_SIZE);
    for(int i = 0; i < huffmanTableSize; i++)
        huffmanTable[i] = nodeArray[i];

	while(nodeArraySize > 1){
        t_node *left = nodeArray[--nodeArraySize];
        t_node *right = nodeArray[--nodeArraySize];
        t_node *newNode = malloc(sizeof(t_node));
        newNode->left = left;
        newNode->right = right;
        newNode->s.frequency = left->s.frequency + right->s.frequency;
        newNode->s.representation = '$';
        nodeArray[nodeArraySize++] = newNode;
        // printTree(newNode, "colored");
        quicksort(nodeArray, 0, nodeArraySize);
    }
	//create huffman table
    int top = 0;
    char arr[height(nodeArray[0])];
    huffmanCompression(&nodeArray[0], arr, top);

	return huffmanTable;
}

void decompress(t_node *root, char *compressed, int *i){
	// printf("compressed[%d]=%c\n", *i, compressed[*i]);
	// printf("nó atual=%c: ", root->s.representation);
	if(isLeaf(root)){
		*i -= 1;
		printf("%c", root->s.representation);
		return;
	}
	if(compressed[*i] == '0'){
		*i += 1;
		// printf("esq!\n");	
		decompress(root->left, compressed, i);
	}
	else if(compressed[*i] == '1'){
		*i += 1;
		// printf("dir!\n");	
		decompress(root->right, compressed, i);
	}
}



