#define ALPHABET_SIZE 128

typedef struct SYMBOL{
    char representation, *codified;
    int frequency;
}Symbol;

// typedef struct TNODE t_node;
typedef struct TNODE{
	Symbol s;
	struct TNODE *left, *right;
}t_node;

typedef struct arvore {
	t_node *root;
}BST;

BST *create();
int isEmpty(BST *a);
void freeTree(t_node *root);
int height(t_node *root);
void printTree(t_node *root, char *option);
void preOrder2(t_node *root);
void preOrder(t_node *root);
char *searchTree(t_node *root, int freq, char *codified, int *x);
void huffmanCompression(t_node **root, char arr[], int top);
int isLeaf(t_node *root);
t_node **createNodeArray(int *charFrequency, int *nNodes);
t_node **createHuffmanTable(t_node** nodeArray, int nodeArraySize);
void decompress(t_node *root, char *compressed, int *i);
