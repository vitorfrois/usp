#include "huffman.h"

void insertionSort(int* arr, int began, int end);
int averagePivo(Node **array, int began, int end);
void quicksort(Node **array, int began, int end);