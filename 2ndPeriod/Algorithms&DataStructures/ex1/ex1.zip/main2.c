#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* readString(int* isNum){
      char *string = malloc(sizeof(char));
      char character = 'o';
      int nCharsString = 0;
      do {
            character = getchar();
            string = realloc(string, (nCharsString + 1) * sizeof(char));
            string[nCharsString] = character;
            nCharsString++;
      } while(character != ' ' && character != '\n' && character != '\r');
      string[nCharsString - 1] = '\0';
      if(character == '\n'){
        ungetc('\n', stdin);
        *isNum = 1;
      }
      return string;
}

typedef struct {
    int n;
    char* word;
}wordList;

void dataCpy(wordList* a, wordList* b){
    a->word = malloc(sizeof(char) * strlen(b->word) + 1);
    strcpy(a->word, b->word);
    a->n = b->n;
}

int dataCmp(wordList* a, wordList* b){
    if(a->n > b->n)
        return 1;
    else if(a->n < b->n)
        return 0;
    else if(a->n == b->n){
        if(strcmp(a->word, b->word) == 1)
            return 1;
        else
            return 0;
    }
    return -1;
}

wordList* insertionSort(wordList* data, int totalWords){
    wordList aux;
    int i, j;
    for (i = 1; i < totalWords; i++) {
        dataCpy(&aux, &data[i]);
        j = i - 1;
        
        /* Move elements of arr[0..i-1], that are
        greater than key, to one position ahead
        of their current position */
        while (j >= 0 && dataCmp(&data[j], &aux)) {
            dataCpy(&data[j+1], &data[j]);
            j--;
        }
        dataCpy(&data[j+1], &aux);
    }
    return data;
}

int main(){
    
    char** read = malloc(sizeof(char*));
    char c;
    int posRead = 0;
    wordList* data = malloc(sizeof(wordList));
    int totalWords = 0;
    int newItem;
    int isNum = 0;
    int toBePrinted;
    while ((c = getchar()) != EOF){
        if(isNum == 0){
            posRead++;
            read = realloc(read, sizeof(char*) * posRead);
            ungetc(c, stdin);
            read[posRead - 1] = readString(&isNum);
            newItem = 1;
            for(int i = 0; i < totalWords; i++){
                if(strcmp(data[i].word, read[posRead-1]) == 0){
                    newItem = 0;
                    data[i].n ++;
                }
            }
            if(newItem == 1){
                totalWords++;
                data = realloc(data, sizeof(wordList) * totalWords); 
                data[totalWords-1].word = malloc(sizeof(char) * strlen(read[posRead - 1]) + 1);
                strcpy(data[totalWords-1].word, read[posRead-1]);
                data[totalWords-1].n = 1;
            }    
        }else{
            ungetc(c, stdin);
            data = insertionSort(data, totalWords);
            scanf("%d\n", &toBePrinted);
            //printf("to be printed = %d\n", toBePrinted);
            for(int i = 0; i < toBePrinted; i++){
                printf("%s ", data[i].word);
                printf("%d\n", data[i].n);
            }
            printf("\n");
            totalWords = 0;
            isNum = 0;
        }
    }

    for(int i = 0; i < totalWords; i++){
        printf("%s ", data[i].word);
        printf("%d\n", data[i].n);
    }   

    for (int i = 0; i < totalWords; i++){
        free(data[i].word);
    }
    free(data);

    for(int i = 0; i < posRead; i++)
        free(read[i]);
    free(read);
    
    return 0;
}