typedef struct WORDLIST wordList;
typedef struct node Node;
int dataCompare(Node*, Node*);
void sortedInsertion(Node*);
void display(Node*);
