Arquivo zip gerado em: 29/09/2021 15:13:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 4