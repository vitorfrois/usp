char* readString(int size);
char* replaceString(char* text, char* error, char* adjust);