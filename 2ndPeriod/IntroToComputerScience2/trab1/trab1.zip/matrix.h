void matrixPrinter(int x, int y, char** matrix, int padding);
void matrixFree(int heigth, char** matrix);
void* mallocAndFill(char** matrix, int heigth, int lenght, int padding);