int neigh(int i, int j, char** matrix);
char** processTips(char** matrix, int heigth, int lenght);
char** recursiveReveal(char** tipMatrix, char** reveleadMatrix, int heigth, int lenght, int m, int n);
