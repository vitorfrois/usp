Arquivo zip gerado em: 23/10/2021 13:46:20 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 02] Compressão de Imagens com Quad-Tree