Arquivo zip gerado em: 24/11/2021 15:46:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 03 - Simulador de Escalonamento de Processos