

public class SegundoPrograma {

	public static void main(String[] args) throws Exception {
		int k;
		
		System.out.printf("Digite um inteiro: ");
		k = EntradaTeclado.leInt();
		System.out.printf("Numero lido: %d\n", k);

	}

}
