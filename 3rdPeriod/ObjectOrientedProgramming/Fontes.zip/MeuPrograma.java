
public class MeuPrograma
{

    public static void main(String args[])
    {
          System.out.println("Meu primeiro programa Java");

    }

}
