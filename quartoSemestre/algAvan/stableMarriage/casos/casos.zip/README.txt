Arquivo zip gerado em: 28/08/2022 09:58:15 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: StabMatch