Arquivo zip gerado em: 15/09/2022 14:38:31 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: BKT 2