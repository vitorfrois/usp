Arquivo zip gerado em: 25/09/2022 15:40:44 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: D&C 2