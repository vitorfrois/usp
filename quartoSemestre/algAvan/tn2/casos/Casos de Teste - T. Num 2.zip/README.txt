Arquivo zip gerado em: 18/11/2022 18:01:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: T. Num 2